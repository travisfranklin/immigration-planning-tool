# Phase 7: Flowchart Requirements for Remaining Countries

**Created By**: Product Manager  
**Date**: 2025-10-19  
**Status**: ✅ Complete

---

## Overview

This document defines the visa programs and requirements for creating immigration process flowcharts for Netherlands, France, Spain, and Italy. Each country requires 5 flowcharts matching the visa programs defined in our viability scoring algorithm.

---

## Netherlands Flowcharts (5 Programs)

### 1. DAFT (Dutch-American Friendship Treaty)
**Program ID**: `nl_daft`  
**Type**: Entrepreneur  
**Target Users**: US citizens wanting to start a business  
**Key Requirements**:
- US citizenship (required)
- €4,500 startup capital
- Business plan
- Processing time: 8 weeks
- Validity: 2 years (renewable)

**Flowchart Focus**:
- Emphasize US citizenship requirement (unique advantage)
- Business plan preparation steps
- Chamber of Commerce registration
- Bank account setup
- IND application process

### 2. Highly Skilled Migrant Visa
**Program ID**: `nl_highly_skilled`  
**Type**: Work  
**Target Users**: Skilled workers with job offers  
**Key Requirements**:
- Job offer from recognized sponsor
- €60,360/year salary (or €44,208 if under 30)
- Bachelor's degree
- Processing time: 4 weeks
- Validity: 5 years

**Flowchart Focus**:
- Finding recognized sponsor employers
- Salary verification
- Document collection
- Fast processing timeline
- 30% ruling tax benefit (optional)

### 3. Orientation Year for Graduates
**Program ID**: `nl_orientation_year`  
**Type**: Job Seeker  
**Target Users**: Recent graduates from top universities  
**Key Requirements**:
- Bachelor's degree from top 200 university
- Within 3 years of graduation
- Under 30 years old
- Processing time: 6 weeks
- Validity: 1 year

**Flowchart Focus**:
- University ranking verification
- Diploma apostille/legalization
- Timeline from graduation
- Job search period
- Transition to work visa

### 4. Self-Employment Visa
**Program ID**: `nl_self_employment`  
**Type**: Entrepreneur  
**Target Users**: Entrepreneurs (non-US citizens)  
**Key Requirements**:
- Business plan (points-based system)
- €15,000 recommended savings
- 3+ years experience
- Processing time: 12 weeks
- Validity: 2 years

**Flowchart Focus**:
- Points system explanation
- Business plan requirements
- KVK registration
- Financial requirements
- Points calculation

### 5. Family Reunification Visa
**Program ID**: `nl_family_reunification`  
**Type**: Family Reunification  
**Target Users**: Family members of Dutch residents  
**Key Requirements**:
- Family member in Netherlands
- Sponsor income requirements
- Processing time: 12 weeks
- Validity: 5 years

**Flowchart Focus**:
- Sponsor eligibility
- Income verification
- Relationship documentation
- MVV application process
- Integration requirements

---

## France Flowcharts (5 Programs)

### 1. Talent Passport (Passeport Talent)
**Program ID**: `fr_talent_passport`  
**Type**: Work  
**Target Users**: Highly skilled workers, researchers, investors  
**Key Requirements**:
- Job offer required
- €53,836/year salary (1.5x minimum wage)
- Master's degree
- Processing time: 8 weeks
- Validity: 4 years

**Flowchart Focus**:
- Multiple categories (skilled worker, researcher, investor, etc.)
- Document requirements per category
- Prefecture application
- Fast-track benefits
- Family inclusion

### 2. Skills and Talents Visa
**Program ID**: `fr_skills_talents`  
**Type**: Work  
**Target Users**: Individuals with exceptional talent  
**Key Requirements**:
- 5+ years experience
- Bachelor's degree
- Proof of exceptional achievements
- Processing time: 12 weeks
- Validity: 3 years

**Flowchart Focus**:
- Defining "exceptional talent"
- Portfolio/achievement documentation
- Recommendation letters
- Project proposal
- No job offer required

### 3. French Tech Visa
**Program ID**: `fr_french_tech`  
**Type**: Entrepreneur  
**Target Users**: Tech startup founders and employees  
**Key Requirements**:
- Business plan
- €30,000 recommended capital
- French Tech ecosystem membership
- Processing time: 8 weeks
- Validity: 4 years

**Flowchart Focus**:
- French Tech ecosystem application
- Incubator/accelerator partnership
- Startup validation
- Fast-track process
- Founder vs employee paths

### 4. Standard Work Visa
**Program ID**: `fr_work_visa`  
**Type**: Work  
**Target Users**: Qualified workers with job offers  
**Key Requirements**:
- Job offer required
- High school diploma minimum
- Labor market test (usually)
- Processing time: 12 weeks
- Validity: 1 year

**Flowchart Focus**:
- Labor market test process
- DIRECCTE approval
- Employer obligations
- Document requirements
- Renewal process

### 5. Family Reunification Visa
**Program ID**: `fr_family_reunification`  
**Type**: Family Reunification  
**Target Users**: Family members of French residents  
**Key Requirements**:
- Family member in France
- A1 French language proficiency
- Sponsor income and housing requirements
- Processing time: 16 weeks
- Validity: 1 year

**Flowchart Focus**:
- Sponsor eligibility
- Language test (DELF/TCF)
- Housing adequacy
- Income requirements
- OFII integration

---

## Spain Flowcharts (5 Programs)

### 1. Golden Visa (Investor Visa)
**Program ID**: `es_golden_visa`  
**Type**: Investor  
**Target Users**: High net worth individuals  
**Key Requirements**:
- €500,000 real estate OR €1M Spanish assets
- No job offer required
- Processing time: 8 weeks
- Validity: 3 years

**Flowchart Focus**:
- Investment options (real estate, bonds, business)
- Property purchase process
- NIE number acquisition
- Fast-track residency
- Family inclusion

### 2. Non-Lucrative Visa
**Program ID**: `es_non_lucrative`  
**Type**: Other (Retirement/Remote)  
**Target Users**: Retirees and remote workers  
**Key Requirements**:
- €28,800/year passive income
- €30,000 recommended savings
- Cannot work in Spain
- Processing time: 12 weeks
- Validity: 1 year

**Flowchart Focus**:
- Passive income documentation
- Health insurance requirements
- Criminal background check
- Consulate application
- Renewal process

### 3. Digital Nomad Visa
**Program ID**: `es_digital_nomad`  
**Type**: Digital Nomad  
**Target Users**: Remote workers  
**Key Requirements**:
- Remote work for non-Spanish company
- €2,400/month income
- Processing time: 8 weeks
- Validity: 1 year (renewable up to 5)

**Flowchart Focus**:
- Remote work documentation
- Employment contract requirements
- Income verification
- Tax implications
- Beckham Law benefits

### 4. Highly Qualified Professional Visa
**Program ID**: `es_highly_qualified`  
**Type**: Work  
**Target Users**: Skilled professionals  
**Key Requirements**:
- Job offer required
- Bachelor's degree
- €30,000/year salary
- Processing time: 10 weeks
- Validity: 2 years

**Flowchart Focus**:
- Job offer requirements
- Degree recognition
- Social security registration
- Work permit process
- EU Blue Card alternative

### 5. Family Reunification Visa
**Program ID**: `es_family_reunification`  
**Type**: Family Reunification  
**Target Users**: Family members of Spanish residents  
**Key Requirements**:
- Family member in Spain
- Sponsor income and housing
- Processing time: 16 weeks
- Validity: 2 years

**Flowchart Focus**:
- Sponsor requirements
- Relationship documentation
- Empadronamiento (registration)
- Income verification
- Integration requirements

---

## Italy Flowcharts (5 Programs)

### 1. Golden Visa (Investor Visa)
**Program ID**: `it_golden_visa`  
**Type**: Investor  
**Target Users**: High net worth investors  
**Key Requirements**:
- €500,000 company OR €1M startup OR €2M government bonds
- No job offer required
- Processing time: 12 weeks
- Validity: 2 years

**Flowchart Focus**:
- Investment options comparison
- Innovative startup criteria
- Government bond process
- Permesso di soggiorno application
- Family inclusion

### 2. Self-Employment Visa
**Program ID**: `it_self_employment`  
**Type**: Entrepreneur  
**Target Users**: Entrepreneurs and freelancers  
**Key Requirements**:
- Business plan
- €30,000 recommended capital
- Processing time: 12 weeks
- Validity: 2 years

**Flowchart Focus**:
- Business plan requirements
- Chamber of Commerce registration
- Nulla osta application
- Quota system (if applicable)
- Partita IVA (VAT number)

### 3. Highly Skilled Worker Visa
**Program ID**: `it_highly_skilled`  
**Type**: Work  
**Target Users**: Skilled workers  
**Key Requirements**:
- Job offer required
- Bachelor's degree
- €25,000/year salary
- Subject to quota system
- Processing time: 12 weeks
- Validity: 2 years

**Flowchart Focus**:
- Quota system (Decreto Flussi)
- Nulla osta process
- Employer sponsorship
- Document requirements
- Conversion to permanent residence

### 4. Digital Nomad Visa
**Program ID**: `it_digital_nomad`  
**Type**: Digital Nomad  
**Target Users**: Remote workers (new 2024)  
**Key Requirements**:
- €28,000/year income
- Remote work for non-Italian company
- Processing time: 10 weeks
- Validity: 1 year

**Flowchart Focus**:
- New visa type (2024)
- Remote work documentation
- Income verification
- Health insurance
- Tax implications

### 5. Family Reunification Visa
**Program ID**: `it_family_reunification`  
**Type**: Family Reunification  
**Target Users**: Family members of Italian residents  
**Key Requirements**:
- Family member in Italy
- Sponsor income and housing
- Processing time: 20 weeks
- Validity: 2 years

**Flowchart Focus**:
- Sponsor requirements
- Income thresholds
- Housing adequacy
- Questura application
- Integration agreement

---

## Flowchart Design Guidelines

### Consistency Requirements
1. **Structure**: All flowcharts should follow Germany's structure (7-11 steps)
2. **Step Format**: Each step should include:
   - Title
   - Description
   - Estimated duration
   - Required documents
   - Important notes
   - Conditional requirements (if applicable)

### Mermaid Diagram Standards
- Use consistent node shapes and colors
- Include decision points where applicable
- Show parallel processes when relevant
- Indicate optional vs required steps

### Document Lists
- Be specific (e.g., "Apostilled birth certificate" not just "birth certificate")
- Include where to obtain documents
- Note translation requirements
- Indicate notarization needs

### User Experience
- Use plain language, avoid jargon
- Provide realistic timelines
- Include helpful tips and warnings
- Link to official resources where possible

---

## Success Criteria

✅ All 20 flowcharts created (5 per country)  
✅ Each flowchart matches corresponding visa program in algorithm  
✅ Consistent structure and quality across all flowcharts  
✅ Accurate processing times and requirements  
✅ User-friendly language and helpful notes  
✅ All flowcharts render correctly in Mermaid.js  

---

**PM Sign-Off**: Requirements complete and ready for implementation by Frontend Engineer.

