# Phase 6: Results & Viability Scoring - Design Document

**Status**: 🔄 In Progress  
**Date**: 2025-10-19

---

## 🎯 Overview

Phase 6 implements the viability scoring algorithm that matches users to the most suitable visa programs across EU countries. The algorithm must be **path-aware** and consider specific visa programs like DAFT, EU Blue Card, Golden Visa, Digital Nomad visas, etc.

---

## 📊 Visa Programs by Country

### 🇩🇪 Germany
1. **EU Blue Card**
   - Requirements: University degree + job offer + min salary (€58,400 or €45,552 for shortage occupations)
   - Target: Highly skilled workers
   - Scoring factors: Education level, salary, occupation demand, job offer status

2. **Job Seeker Visa**
   - Requirements: University degree + proof of funds
   - Duration: 6 months to find work
   - Scoring factors: Education level, savings, occupation demand
   - Note: Lower score if user already has job offer (should use EU Blue Card instead)

3. **Freelance Visa (Freiberufler)**
   - Requirements: Proof of clients/contracts, relevant qualifications
   - Target: Self-employed professionals
   - Scoring factors: Occupation type, experience, financial stability

4. **Standard Work Visa**
   - Requirements: Job offer + qualifications
   - Scoring factors: Occupation, education, salary, job offer status

5. **Family Reunification Visa**
   - Requirements: Spouse/parent with valid residence permit + proof of relationship + adequate housing + health insurance
   - Target: Family members of residents
   - Scoring factors: Family ties in Germany, financial stability of sponsor

### 🇳🇱 Netherlands
1. **DAFT (Dutch-American Friendship Treaty)**
   - Requirements: US citizen + €4,500 startup capital
   - Target: Entrepreneurs
   - Scoring factors: Savings, business plan viability, entrepreneurial background

2. **Highly Skilled Migrant Visa**
   - Requirements: Job offer from recognized sponsor + min salary (€5,008/month or €3,672 for under 30)
   - Target: Skilled workers
   - Scoring factors: Salary, education, occupation, job offer status

3. **Orientation Year for Graduates**
   - Requirements: Degree from top 200 university (within 3 years)
   - Duration: 1 year to find work
   - Scoring factors: Education level, university ranking, age
   - Note: Lower score if user already has job offer (should use Highly Skilled Migrant instead)

4. **Self-Employment Visa**
   - Requirements: Business plan + proof of funds
   - Scoring factors: Business viability, financial resources

5. **Family Reunification Visa**
   - Requirements: Spouse/partner/child with valid residence permit + proof of relationship + adequate income
   - Target: Family members of residents
   - Scoring factors: Family ties in Netherlands, financial stability of sponsor

### 🇫🇷 France
1. **Talent Passport (Passeport Talent)**
   - Requirements: Varies by category (highly skilled, investor, researcher, etc.)
   - Min salary: €53,836.50/year
   - Scoring factors: Occupation, salary, education, special skills, job offer status

2. **Skills and Talents Visa**
   - Requirements: Exceptional talent in field
   - Scoring factors: Professional achievements, recognition

3. **French Tech Visa**
   - Requirements: Startup founder/employee/investor
   - Scoring factors: Tech skills, startup funding, innovation

4. **Standard Work Visa**
   - Requirements: Job offer + labor market test
   - Scoring factors: Occupation demand, qualifications, job offer status

5. **Family Reunification Visa**
   - Requirements: Spouse/child with valid residence permit + proof of relationship + adequate housing + health insurance
   - Target: Family members of residents
   - Scoring factors: Family ties in France, financial stability of sponsor

### 🇪🇸 Spain
1. **Golden Visa (Investor Visa)**
   - Requirements: €500,000 real estate investment OR €1M in Spanish assets
   - Target: High net worth individuals
   - Scoring factors: Savings/assets, investment capacity

2. **Non-Lucrative Visa**
   - Requirements: Proof of income (€28,800/year) + no work allowed
   - Target: Retirees, remote workers with foreign income
   - Scoring factors: Passive income, savings

3. **Digital Nomad Visa**
   - Requirements: Remote work for non-Spanish company + min income (€2,334/month)
   - Target: Remote workers
   - Scoring factors: Remote work capability, income, occupation

4. **Highly Qualified Professional Visa**
   - Requirements: University degree + job offer + min salary
   - Scoring factors: Education, salary, occupation demand, job offer status

5. **Family Reunification Visa**
   - Requirements: Spouse/child with valid residence permit + proof of relationship + adequate income
   - Target: Family members of residents
   - Scoring factors: Family ties in Spain, financial stability of sponsor

### 🇮🇹 Italy
1. **Golden Visa (Investor Visa)**
   - Requirements: €2M government bonds OR €500k company investment OR €1M startup
   - Target: Investors
   - Scoring factors: Investment capacity, assets

2. **Self-Employment Visa**
   - Requirements: Business plan + proof of funds
   - Target: Entrepreneurs, freelancers
   - Scoring factors: Business viability, financial resources, occupation

3. **Highly Skilled Worker Visa**
   - Requirements: Job offer + qualifications
   - Scoring factors: Education, occupation demand, salary, job offer status

4. **Digital Nomad Visa** (New 2024)
   - Requirements: Remote work + min income (€28,000/year)
   - Target: Remote workers
   - Scoring factors: Remote work capability, income

5. **Family Reunification Visa**
   - Requirements: Spouse/child with valid residence permit + proof of relationship + adequate income
   - Target: Family members of residents
   - Scoring factors: Family ties in Italy, financial stability of sponsor

---

## 🧮 Revised Scoring Algorithm

### Multi-Path Approach

For each country, the algorithm will:
1. **Evaluate ALL visa programs** the user might qualify for
2. **Calculate a viability score for EACH program**
3. **Select the BEST program** (highest score) as the recommended path
4. **Use the best program's score** as the country's overall score

### Component Scoring (Per Visa Program)

Each visa program has different weights for components:

#### Example: Germany EU Blue Card
```
Overall Score = (
  Career Score × 0.35 +      // Higher weight - job offer critical
  Financial Score × 0.25 +   // Salary requirements
  Education Score × 0.30 +   // University degree required
  Language Score × 0.05 +    // Less critical initially
  Family Score × 0.05        // Less critical
)
```

#### Example: Netherlands DAFT
```
Overall Score = (
  Career Score × 0.20 +      // Entrepreneurial background
  Financial Score × 0.40 +   // €4,500 capital required
  Education Score × 0.15 +   // Less critical
  Language Score × 0.10 +    // Moderate importance
  Family Score × 0.15        // Moderate importance
)
```

#### Example: Spain Golden Visa
```
Overall Score = (
  Career Score × 0.05 +      // Not relevant
  Financial Score × 0.80 +   // €500k+ investment required
  Education Score × 0.05 +   // Not relevant
  Language Score × 0.05 +    // Not relevant
  Family Score × 0.05        // Not relevant
)
```

### Program-Specific Scoring Logic

Each visa program will have:
1. **Eligibility Check**: Hard requirements (pass/fail)
2. **Component Weights**: Custom weights for that program
3. **Bonus/Penalty Factors**: Program-specific adjustments

### User Preferences Impact on Scoring

The algorithm considers user-selected preferences from the profile:

#### 1. **Immigration Path** (from Step 6)
- **Work Visa**: Prioritize work visa programs, penalize investor/retirement visas
- **Permanent Residency**: Prioritize programs with clear PR path, boost long-term viability
- **Citizenship**: Prioritize programs with citizenship path, consider naturalization timeline

#### 2. **Target Countries** (from Step 6)
- **Selected Countries**: Boost scores by 10-15% for user-selected target countries
- **Non-Selected Countries**: Still calculate but with lower priority/visibility
- **Rationale**: User has already researched and expressed interest

#### 3. **Timeline** (from Step 6)
- **Short Timeline (< 12 months)**:
  - Boost programs with fast processing times
  - Penalize programs requiring extensive preparation
  - Prioritize programs where user already meets requirements
- **Medium Timeline (12-36 months)**:
  - Balanced scoring
  - Consider programs where user can improve qualifications
- **Long Timeline (> 36 months)**:
  - Consider all programs
  - Include programs requiring significant preparation

#### 4. **Job Offer Status** (from Step 6)
- **Has Job Offer**:
  - Massive boost (+30-40 points) for programs requiring job offer
  - Penalize job seeker visas (redundant)
  - Boost country matching job offer location
- **No Job Offer**:
  - Prioritize job seeker visas, entrepreneur visas, investor visas
  - Penalize programs requiring job offer (but still show as "future option")

#### 5. **Family Members** (from Step 5)
- **Has Dependents (spouse/children)**:
  - Boost family reunification programs
  - Consider family visa costs in financial scoring
  - Prioritize countries with family-friendly policies
  - Add risk factors for family separation
- **No Dependents**:
  - Standard scoring
  - No family reunification consideration

#### 6. **Job Offer Country** (from Step 6)
- If user has job offer in specific country:
  - Boost that country's score significantly (+20-30 points)
  - Prioritize work visa programs for that country
  - Lower timeline requirements (already has critical component)

---

## 📁 New Data Structure

### VisaProgram Interface
```typescript
interface VisaProgram {
  id: string;
  countryCode: string;
  name: string;
  type: 'work' | 'entrepreneur' | 'investor' | 'digital_nomad' | 'family_reunification' | 'student' | 'other';

  // Eligibility Requirements (Hard Requirements)
  requirements: {
    minSalary?: number;
    minInvestment?: number;
    minSavings?: number;
    minEducationLevel?: EducationLevel;
    minLanguageProficiency?: LanguageProficiency;
    requiresJobOffer?: boolean;
    requiresBusinessPlan?: boolean;
    allowedOccupations?: string[]; // ISCO codes
    citizenship?: string[]; // e.g., ['US'] for DAFT
    maxAge?: number;
    minAge?: number;
    requiresFamilyInCountry?: boolean; // For family reunification
  };

  // Scoring Weights (for this specific program)
  weights: {
    career: number;
    financial: number;
    education: number;
    language: number;
    family: number;
  };

  // Additional Info
  processingTimeWeeks: number;
  validityYears: number;
  pathToPermanentResidency: boolean;
  pathToCitizenship: boolean;

  // Metadata
  description: string;
  officialUrl?: string;
  notes?: string;
}
```

### Updated ViabilityScore Interface
```typescript
interface ViabilityScore {
  // ... existing fields ...

  // NEW: Program-specific info
  recommendedProgram?: {
    programId: string;
    programName: string;
    programType: string;
    eligibilityScore: number; // 0-100
    matchReason: string;
    alignsWithUserPath: boolean; // Does it match user's selected immigration path?
    alignsWithTimeline: boolean; // Can it be achieved in user's timeline?
    requiresJobOffer: boolean;
  };

  // NEW: Alternative programs
  alternativePrograms?: Array<{
    programId: string;
    programName: string;
    eligibilityScore: number;
    whyNotRecommended: string; // e.g., "Requires job offer", "Timeline too long"
  }>;

  // NEW: User preference alignment
  userPreferenceBoost: number; // Points added based on target countries, timeline, etc.
}
```

---

## 🔧 Implementation Plan

### 1. Expand Country Rules Data
- Create `src/data/visaPrograms.ts` with all visa programs
- Seed IndexedDB with visa program data
- Update CountryRules to reference visa programs

### 2. Create Visa Program Matcher
- `src/services/viability/programMatcher.ts`
- Evaluate user eligibility for each program
- Apply user preference filters (immigration path, timeline, job offer)
- Rank programs by viability

### 3. Create User Preference Scorer
- `src/services/viability/preferenceScorer.ts`
- Calculate boost/penalty based on target countries
- Adjust scores based on timeline alignment
- Boost programs matching immigration path
- Boost programs when job offer exists

### 4. Create Program-Specific Scorers
- Each visa program type gets custom scoring logic
- `src/services/viability/scorers/programScorers/`
- Family reunification scorer (checks for family in country)

### 5. Update Calculator
- Calculate scores for all eligible programs
- Apply user preference adjustments
- Select best program per country
- Generate program-specific recommendations
- Consider family members in scoring

### 6. Update Results UI
- Display recommended visa program
- Show alternative programs
- Explain why each program was recommended
- Show alignment with user preferences
- Display family considerations if applicable

---

## 🎯 Success Criteria

1. ✅ Algorithm correctly identifies eligible visa programs
2. ✅ Scores reflect program-specific requirements
3. ✅ Users see the most suitable visa program for each country
4. ✅ Alternative programs are suggested when applicable
5. ✅ Risk factors are program-specific
6. ✅ Contingencies account for program requirements
7. ✅ User preferences (immigration path, timeline, target countries, job offer) significantly impact scores
8. ✅ Family members are considered in scoring and program recommendations
9. ✅ Job offer status boosts relevant programs and countries
10. ✅ Timeline alignment is clearly communicated to users

---

## 📝 Example Scoring Scenarios

### Scenario 1: Software Engineer with Job Offer in Germany
- **Profile**: BS in CS, 5 years experience, €70k job offer in Berlin, no family
- **Immigration Path**: Work Visa
- **Timeline**: 6 months
- **Result**:
  - 🇩🇪 Germany: 92/100 (EU Blue Card) - **RECOMMENDED**
  - 🇳🇱 Netherlands: 78/100 (Highly Skilled Migrant)
  - 🇫🇷 France: 75/100 (Talent Passport)

### Scenario 2: Entrepreneur with $100k Savings
- **Profile**: MBA, 10 years experience, $100k savings, spouse + 2 kids
- **Immigration Path**: Permanent Residency
- **Timeline**: 12 months
- **Result**:
  - 🇳🇱 Netherlands: 88/100 (DAFT) - **RECOMMENDED**
  - 🇩🇪 Germany: 72/100 (Freelance Visa)
  - 🇮🇹 Italy: 68/100 (Self-Employment)

### Scenario 3: Retiree with Passive Income
- **Profile**: No degree, retired, $60k/year passive income, $500k savings
- **Immigration Path**: Permanent Residency
- **Timeline**: 24 months
- **Result**:
  - 🇪🇸 Spain: 85/100 (Non-Lucrative Visa) - **RECOMMENDED**
  - 🇵🇹 Portugal: 82/100 (D7 Visa - if added)
  - 🇮🇹 Italy: 70/100 (Elective Residence - if added)

---

**Next Steps**:
1. Get approval on this design
2. Create visa programs data for all 5 countries
3. Implement program matcher with user preference filtering
4. Implement scoring algorithm with preference adjustments
5. Build Results UI with program recommendations

