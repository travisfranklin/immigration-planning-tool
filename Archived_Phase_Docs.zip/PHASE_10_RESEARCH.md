# 🌊 PHASE 10 RESEARCH - MEDITERRANEAN COUNTRIES

**Date**: 2025-10-20  
**Countries**: Portugal 🇵🇹, Greece 🇬🇷, Cyprus 🇨🇾, Malta 🇲🇹  
**Status**: 🔍 **IN PROGRESS**

---

## 🇵🇹 PORTUGAL RESEARCH

### Official Sources
- **SEF (Immigration Service)**: https://imigrante.sef.pt/en/
- **Portugal Golden Visa**: https://www.goldenvisa.pt/
- **D7 Visa Information**: https://www.portugal.gov.pt/
- **Tech Visa**: https://www.iapmei.pt/techvisa
- **Startup Visa**: https://startupportugal.com/

### 🇵🇹 Portugal - Visa Programs

#### 1. **Golden Visa (Portugal)**
**Requirements**:
- Investment options:
  - Real estate: €500,000 (or €400,000 in low-density areas)
  - Capital transfer: €1,500,000
  - Business investment: €500,000 (creating 5+ jobs)
  - Research/Arts: €250,000
- Minimum stay: 7 days per year (very flexible!)
- Clean criminal record
- Health insurance

**Processing Time**: 90-180 days
**Validity**: 1 year initially, renewable for 2-year periods
**Path to PR**: 5 years
**Path to Citizenship**: 5 years (with A2 Portuguese language)
**Notes**: One of the most popular Golden Visa programs in EU. Very flexible residency requirements. Family members included. Can work and study. Access to Schengen area.

---

#### 2. **D7 Visa (Passive Income Visa)** ⭐ MOST POPULAR
**Requirements**:
- Passive income: Minimum €760/month (Portuguese minimum wage)
- Recommended: €1,000-€1,500/month for comfortable approval
- Income sources: Pension, rental income, dividends, royalties, remote work
- Proof of accommodation in Portugal
- Health insurance
- Clean criminal record

**Processing Time**: 60-90 days
**Validity**: 2 years initially, renewable
**Path to PR**: 5 years
**Path to Citizenship**: 5 years (with A2 Portuguese language)
**Notes**: EXTREMELY popular with digital nomads and retirees. Very affordable income requirement. Must spend majority of year in Portugal (183+ days). Can work remotely for foreign companies. Family members included.

---

#### 3. **Tech Visa (Portugal)**
**Requirements**:
- Job offer from certified Portuguese tech company
- Salary: Minimum €1,330/month (1.5x Portuguese minimum wage)
- Company must be certified by IAPMEI
- Relevant qualifications or experience in tech
- Health insurance

**Processing Time**: 30-60 days (fast!)
**Validity**: 2 years initially, renewable
**Path to PR**: 5 years
**Path to Citizenship**: 5 years
**Notes**: Fast-track visa for tech workers. Lower salary requirement than most EU countries. Growing tech scene in Lisbon and Porto. Family members can join.

---

#### 4. **Startup Visa (Portugal)**
**Requirements**:
- Innovative business idea approved by certified incubator
- Business plan
- Sufficient funds: €5,000-€10,000 recommended
- Incubator certification from IAPMEI
- Health insurance

**Processing Time**: 60-90 days
**Validity**: 1 year initially, renewable for 2-year periods
**Path to PR**: 5 years
**Path to Citizenship**: 5 years
**Notes**: Must be accepted by certified incubator. Growing startup ecosystem in Lisbon. Can bring co-founders. Family members included.

---

#### 5. **Family Reunification (Portugal)**
**Requirements**:
- Family member with valid Portuguese residence permit
- Proof of relationship (marriage certificate, birth certificate)
- Proof of accommodation
- Proof of sponsor's income (sufficient to support family)
- Health insurance

**Processing Time**: 90-120 days
**Validity**: Same as sponsor's permit
**Path to PR**: 5 years
**Path to Citizenship**: 5 years
**Notes**: Includes spouse, children, parents. Same-sex marriages recognized. Family members can work and study.

---

### 🇵🇹 Portugal Summary

**Strengths**:
- Very affordable (D7 Visa only €760/month income!)
- Multiple pathways (Golden Visa, D7, Tech Visa, Startup)
- Fast citizenship (5 years)
- Non-habitual resident tax regime (0-10% tax for 10 years!)
- English widely spoken in cities
- Strong expat community
- Beautiful climate and lifestyle
- Low cost of living

**Challenges**:
- Portuguese language required for citizenship (A2 level)
- D7 requires 183+ days/year in Portugal
- Golden Visa real estate prices increased recently
- Bureaucracy can be slow

**Best For**:
- Digital nomads (D7 Visa)
- Retirees with passive income (D7 Visa)
- Investors (Golden Visa)
- Tech workers (Tech Visa)
- Entrepreneurs (Startup Visa)

---

## 🇬🇷 GREECE RESEARCH

### Official Sources
- **Greek Ministry of Migration**: https://migration.gov.gr/en/
- **Greece Golden Visa**: https://www.goldenvisa.gr/
- **Digital Nomad Visa**: https://www.gov.gr/en/
- **Enterprise Greece**: https://www.enterprisegreece.gov.gr/

### 🇬🇷 Greece - Visa Programs

#### 1. **Golden Visa (Greece)** ⭐ LOWEST IN EU
**Requirements**:
- Real estate investment: €250,000 (LOWEST in EU!)
- Or €400,000 in certain areas (new rules 2023)
- Clean criminal record
- Health insurance
- Minimum stay: None required!

**Processing Time**: 60-90 days
**Validity**: 5 years, renewable
**Path to PR**: 5 years
**Path to Citizenship**: 7 years
**Notes**: Lowest Golden Visa threshold in EU! No minimum stay requirement. Family members included. Can rent out property. Access to Schengen area. Very popular program.

---

#### 2. **Digital Nomad Visa (Greece)**
**Requirements**:
- Monthly income: €3,500/month (€42,000/year)
- Remote work for non-Greek company OR self-employed
- Proof of employment/contracts
- Health insurance
- Clean criminal record

**Processing Time**: 30-60 days
**Validity**: 1 year initially, renewable for 2 years
**Path to PR**: 5 years
**Path to Citizenship**: 7 years
**Notes**: Launched in 2021. 50% income tax reduction for first year! Can work from Greek islands. Growing digital nomad community.

---

#### 3. **Independent Means Visa (Greece)**
**Requirements**:
- Passive income: €2,000/month (€24,000/year)
- +20% for spouse, +15% per child
- Proof of stable income (pension, investments, rental income)
- Health insurance
- Proof of accommodation

**Processing Time**: 60-90 days
**Validity**: 2 years, renewable
**Path to PR**: 5 years
**Path to Citizenship**: 7 years
**Notes**: For retirees and those with passive income. Must spend 183+ days/year in Greece. Very low cost of living makes this attractive.

---

#### 4. **Work Permit (Greece)**
**Requirements**:
- Job offer from Greek employer
- Salary: Minimum €1,200/month
- Employer must prove no suitable Greek/EU candidate
- Relevant qualifications
- Health insurance

**Processing Time**: 90-120 days
**Validity**: 1-2 years, renewable
**Path to PR**: 5 years
**Path to Citizenship**: 7 years
**Notes**: Standard work permit. Growing tech sector in Athens and Thessaloniki. Family members can join.

---

#### 5. **Family Reunification (Greece)**
**Requirements**:
- Family member with valid Greek residence permit
- Proof of relationship
- Proof of accommodation
- Proof of sponsor's income
- Health insurance

**Processing Time**: 90-120 days
**Validity**: Same as sponsor's permit
**Path to PR**: 5 years
**Path to Citizenship**: 7 years
**Notes**: Includes spouse, children, parents. Family members can work and study.

---

### 🇬🇷 Greece Summary

**Strengths**:
- Lowest Golden Visa in EU (€250k!)
- Very low cost of living
- Beautiful islands and climate
- Digital nomad visa with tax benefits
- No minimum stay for Golden Visa
- Growing expat community

**Challenges**:
- Greek language required for citizenship
- Bureaucracy can be complex
- Economic challenges in recent years
- Work permit requires labor market test

**Best For**:
- Investors (Golden Visa - cheapest in EU!)
- Digital nomads (Digital Nomad Visa)
- Retirees (Independent Means)
- Those seeking Mediterranean lifestyle

---

## 🇨🇾 CYPRUS RESEARCH

### Official Sources
- **Cyprus Migration Department**: https://www.moi.gov.cy/moi/crmd/
- **Cyprus Investment Programme**: https://www.cyprusisland.net/
- **Invest Cyprus**: https://www.investcyprus.org.cy/

### 🇨🇾 Cyprus - Visa Programs

#### 1. **Golden Visa (Cyprus)**
**Requirements**:
- Real estate investment: €300,000
- Or business investment: €300,000
- Or combination of investments: €300,000 total
- Proof of annual income: €50,000 (+€15,000 per dependent)
- Clean criminal record
- Health insurance

**Processing Time**: 60-90 days
**Validity**: Permanent (renewable every 5 years)
**Path to PR**: Immediate (this IS permanent residence)
**Path to Citizenship**: 7 years
**Notes**: One of the fastest PR programs in EU. English is official language. Low taxes (12.5% corporate). Strategic location.

---

#### 2. **Startup Visa (Cyprus)**
**Requirements**:
- Innovative business idea
- Approval from Cyprus Deputy Ministry of Research
- Sufficient funds: €20,000 minimum
- Business plan
- Health insurance

**Processing Time**: 60-90 days
**Validity**: 1 year initially, renewable
**Path to PR**: 5 years
**Path to Citizenship**: 7 years
**Notes**: Growing startup ecosystem. English-speaking. EU market access. Tax benefits for startups.

---

#### 3. **Work Permit (Cyprus)**
**Requirements**:
- Job offer from Cypriot employer
- Salary: Minimum €1,500/month
- Employer must be registered in Cyprus
- Relevant qualifications
- Health insurance

**Processing Time**: 60-90 days
**Validity**: 1-3 years, renewable
**Path to PR**: 5 years
**Path to Citizenship**: 7 years
**Notes**: English is official language (major advantage!). Growing tech and finance sectors. Family can join.

---

#### 4. **Digital Nomad Visa (Cyprus)**
**Requirements**:
- Monthly income: €3,500/month (€42,000/year)
- Remote work for non-Cypriot company OR self-employed
- Proof of employment/contracts
- Health insurance
- Clean criminal record

**Processing Time**: 30-60 days
**Validity**: 1 year, renewable for 2 more years
**Path to PR**: Does not lead to PR (temporary program)
**Path to Citizenship**: N/A
**Notes**: Launched in 2021. Tax benefits. English-speaking. Warm climate year-round. Good internet infrastructure.

---

#### 5. **Family Reunification (Cyprus)**
**Requirements**:
- Family member with valid Cyprus residence permit
- Proof of relationship
- Proof of accommodation
- Proof of sponsor's income (€1,500/month + €500 per dependent)
- Health insurance

**Processing Time**: 60-90 days
**Validity**: Same as sponsor's permit
**Path to PR**: 5 years
**Path to Citizenship**: 7 years
**Notes**: English-speaking environment. Family members can work and study. Same-sex partnerships recognized.

---

### 🇨🇾 Cyprus Summary

**Strengths**:
- English is official language (HUGE advantage!)
- Low corporate tax (12.5%)
- Fast Golden Visa to PR
- Warm climate year-round
- Strategic location (Europe/Asia/Africa)
- EU member with euro currency

**Challenges**:
- Divided island (North/South)
- Small island (limited job market)
- Higher cost of living than Greece/Portugal
- Digital Nomad visa doesn't lead to PR

**Best For**:
- English speakers
- Investors (Golden Visa)
- Digital nomads (short-term)
- Finance/tech professionals
- Those seeking tax benefits

---

## 🇲🇹 MALTA RESEARCH

### Official Sources
- **Identity Malta**: https://identitymalta.com/
- **Malta Nomad Residence**: https://nomad.residencymalta.gov.mt/
- **Malta Global Residence Programme**: https://residencymalta.gov.mt/
- **Jobsplus Malta**: https://jobsplus.gov.mt/

### 🇲🇹 Malta - Visa Programs

#### 1. **Malta Permanent Residence Programme (MPRP)** (Golden Visa)
**Requirements**:
- Investment options:
  - Buy property: €300,000 (South Malta/Gozo) or €350,000 (rest of Malta)
  - Rent property: €10,000/year (South/Gozo) or €12,000/year (rest)
- Government contribution: €28,000 (rent) or €68,000 (buy)
- Donation: €2,000 to NGO
- Proof of assets: €500,000
- Annual income: €100,000 OR assets €500,000
- Health insurance
- Clean criminal record

**Processing Time**: 120-180 days
**Validity**: Permanent
**Path to PR**: Immediate (this IS permanent residence)
**Path to Citizenship**: 5 years (with naturalization)
**Notes**: English is official language. EU member. Tax benefits. Family included. No minimum stay requirement.

---

#### 2. **Nomad Residence Permit (Malta)**
**Requirements**:
- Monthly income: €2,700/month (€32,400/year) as main applicant
- Remote work for non-Maltese company OR self-employed
- Proof of employment contract or business ownership
- Health insurance (minimum €30,000 coverage)
- Rental agreement or property ownership in Malta
- Clean criminal record

**Processing Time**: 30-60 days
**Validity**: 1 year, renewable for up to 3 years total
**Path to PR**: Does not lead to PR (temporary program)
**Path to Citizenship**: N/A
**Notes**: Launched in 2021. Flat tax rate of 15% on foreign income. English-speaking. EU member. Good internet. Warm climate.

---

#### 3. **Highly Skilled Worker Permit (Malta)**
**Requirements**:
- Job offer from Maltese employer in highly skilled occupation
- Salary: Minimum €30,000/year
- Relevant qualifications (degree or equivalent experience)
- Employer must be registered in Malta
- Health insurance

**Processing Time**: 60-90 days
**Validity**: 1-3 years, renewable
**Path to PR**: 5 years
**Path to Citizenship**: 5 years
**Notes**: English is official language. Growing tech, gaming, and finance sectors. iGaming hub of Europe. Family can join.

---

#### 4. **Startup Visa (Malta)**
**Requirements**:
- Innovative business idea
- Approval from Malta Enterprise
- Business plan
- Sufficient funds: €15,000-€25,000 recommended
- Health insurance
- Clean criminal record

**Processing Time**: 60-90 days
**Validity**: 1 year initially, renewable
**Path to PR**: 5 years
**Path to Citizenship**: 5 years
**Notes**: Growing startup ecosystem. English-speaking. EU market access. Tax incentives for startups. Small but well-connected business community.

---

#### 5. **Family Reunification (Malta)**
**Requirements**:
- Family member with valid Malta residence permit
- Proof of relationship (marriage certificate, birth certificate)
- Proof of accommodation in Malta
- Proof of sponsor's income (sufficient to support family)
- Health insurance (€30,000 minimum coverage)
- Clean criminal record

**Processing Time**: 90-120 days
**Validity**: Same as sponsor's permit
**Path to PR**: 5 years
**Path to Citizenship**: 5 years
**Notes**: English-speaking. Family members can work and study. Same-sex marriages recognized. Includes spouse, children, dependent parents.

---

### 🇲🇹 Malta Summary

**Strengths**:
- English is official language (HUGE advantage!)
- EU member with euro currency
- Excellent tax benefits (15% flat tax for nomads, various schemes for residents)
- Fast citizenship (5 years)
- Warm climate year-round
- Strategic location in Mediterranean
- Strong finance, gaming, and tech sectors
- Small island (easy to navigate)

**Challenges**:
- Small island (can feel isolated)
- Higher cost of living than Greece/Portugal
- Limited job market (small population)
- Golden Visa requires significant investment
- Traffic congestion

**Best For**:
- English speakers
- Digital nomads (Nomad Residence)
- Finance/gaming/tech professionals
- Investors (MPRP)
- Those seeking tax benefits
- Those who want fast EU citizenship

---

## 📊 RESEARCH STATUS

| Country | Status | Programs Researched | Official Sources |
|---------|--------|---------------------|------------------|
| 🇵🇹 Portugal | ✅ COMPLETE | 5/5 | ✅ |
| 🇬🇷 Greece | ✅ COMPLETE | 5/5 | ✅ |
| 🇨🇾 Cyprus | ✅ COMPLETE | 5/5 | ✅ |
| 🇲🇹 Malta | ✅ COMPLETE | 5/5 | ✅ |

---

## 🎯 PHASE 10 RESEARCH COMPLETE!

All 4 Mediterranean countries researched with 20 visa programs total!

### Key Findings

**Golden Visa Comparison**:
- 🇬🇷 Greece: €250,000 (LOWEST!)
- 🇨🇾 Cyprus: €300,000 (immediate PR)
- 🇲🇹 Malta: €300,000+ (immediate PR, tax benefits)
- 🇵🇹 Portugal: €500,000 (most flexible residency)

**Digital Nomad Programs**:
- 🇵🇹 Portugal: D7 Visa (€760/month - LOWEST!)
- 🇬🇷 Greece: €3,500/month (tax benefits)
- 🇨🇾 Cyprus: €3,500/month (English-speaking)
- 🇲🇹 Malta: €2,700/month (15% flat tax, English-speaking)

**English-Speaking**:
- 🇨🇾 Cyprus: Official language ✅
- 🇲🇹 Malta: Official language ✅
- 🇵🇹 Portugal: Widely spoken in cities
- 🇬🇷 Greece: Common in tourist areas

**Best Value**:
- 🇵🇹 Portugal: D7 Visa (€760/month!)
- 🇬🇷 Greece: Golden Visa (€250k!)
- 🇬🇷 Greece: Lowest cost of living

**Fastest Citizenship**:
- 🇵🇹 Portugal: 5 years
- 🇲🇹 Malta: 5 years
- 🇨🇾 Cyprus: 7 years
- 🇬🇷 Greece: 7 years

---

**Architecture Engineer**: ✅ Research complete for all 4 countries! Ready for implementation.

**Next Step**: Frontend Engineer to begin Portugal implementation.

