# Phase 2 Implementation Guide: Local Storage & Core Forms

**Objective**: Implement local data storage and core data collection forms  
**Duration**: 2-3 weeks  
**Target Completion**: Ready for Phase 3 (Algorithm Implementation)

## Phase 2 Breakdown

### Task 1: Project Initialization (1-2 days)
```bash
# Initialize React + Vite project
npm create vite@latest immigration-pipeline -- --template react-ts

# Install core dependencies
npm install react-router-dom zustand
npm install -D tailwindcss postcss autoprefixer
npm install -D typescript @types/react @types/react-dom

# Initialize Tailwind
npx tailwindcss init -p

# Install testing dependencies
npm install -D vitest @testing-library/react @testing-library/jest-dom
npm install -D @playwright/test
```

**Deliverables**:
- [ ] Vite project initialized with React + TypeScript
- [ ] Tailwind CSS configured
- [ ] Project structure created per ARCHITECTURE.md
- [ ] Development server running successfully

### Task 2: IndexedDB Integration (2-3 days)

**Files to Create**:
- `src/services/storage/indexedDB.ts` - Core IndexedDB wrapper
- `src/services/storage/userProfileStore.ts` - User profile operations
- `src/services/storage/viabilityScoreStore.ts` - Viability score operations
- `src/types/user.ts` - TypeScript interfaces
- `src/types/viability.ts` - Viability score types

**Key Functions**:
```typescript
// indexedDB.ts
- initializeDatabase(): Promise<void>
- getStore(storeName: string): IDBObjectStore
- addRecord(storeName: string, data: any): Promise<string>
- updateRecord(storeName: string, id: string, data: any): Promise<void>
- deleteRecord(storeName: string, id: string): Promise<void>
- getRecord(storeName: string, id: string): Promise<any>
- getAllRecords(storeName: string): Promise<any[]>

// userProfileStore.ts
- createProfile(profile: UserProfile): Promise<string>
- getProfile(id: string): Promise<UserProfile>
- updateProfile(id: string, updates: Partial<UserProfile>): Promise<void>
- deleteProfile(id: string): Promise<void>
- getAllProfiles(): Promise<UserProfile[]>
```

**Deliverables**:
- [ ] IndexedDB database initialized with three stores
- [ ] CRUD operations for user profiles
- [ ] CRUD operations for viability scores
- [ ] Type-safe storage layer
- [ ] Unit tests for storage operations

### Task 3: Custom React Hooks (1-2 days)

**Files to Create**:
- `src/hooks/useUserProfile.ts` - Profile management hook
- `src/hooks/useLocalStorage.ts` - Generic local storage hook
- `src/hooks/useViabilityScores.ts` - Viability score management

**Key Hooks**:
```typescript
// useUserProfile.ts
- useUserProfile(profileId?: string)
  - profile: UserProfile | null
  - loading: boolean
  - error: Error | null
  - createProfile(data: UserProfile): Promise<string>
  - updateProfile(updates: Partial<UserProfile>): Promise<void>
  - deleteProfile(): Promise<void>

// useLocalStorage.ts
- useLocalStorage<T>(key: string, initialValue: T)
  - value: T
  - setValue(value: T): void
  - removeValue(): void
```

**Deliverables**:
- [ ] Custom hooks for profile management
- [ ] Custom hooks for local storage access
- [ ] Proper error handling and loading states
- [ ] Hook unit tests

### Task 4: Form Components (3-4 days)

**Files to Create**:
- `src/components/forms/PersonalInfoForm.tsx`
- `src/components/forms/FinancialInfoForm.tsx`
- `src/components/forms/EducationForm.tsx`
- `src/components/forms/CareerForm.tsx`
- `src/components/forms/FamilyForm.tsx`
- `src/components/forms/LanguageForm.tsx`
- `src/components/forms/CountrySelectionForm.tsx`

**Form Requirements**:
- [ ] Input validation (required fields, data types, ranges)
- [ ] Error messages and visual feedback
- [ ] Auto-save to IndexedDB on blur or after debounce
- [ ] Loading states during save
- [ ] Responsive design (mobile-first)
- [ ] Accessibility (ARIA labels, keyboard navigation)

**Deliverables**:
- [ ] All 7 form components implemented
- [ ] Form validation logic
- [ ] Auto-save functionality
- [ ] Error handling and user feedback
- [ ] Component tests

### Task 5: Multi-Step Form Container (2-3 days)

**Files to Create**:
- `src/components/forms/ProfileFormContainer.tsx`
- `src/pages/ProfilePage.tsx`

**Features**:
- [ ] Step navigation (Previous/Next buttons)
- [ ] Progress indicator
- [ ] Form state management across steps
- [ ] Validation before advancing
- [ ] Save confirmation
- [ ] Ability to edit previous steps

**Deliverables**:
- [ ] Multi-step form container
- [ ] Profile page with form integration
- [ ] Navigation between steps
- [ ] Progress tracking

### Task 6: Layout & Navigation (1-2 days)

**Files to Create**:
- `src/components/layout/Header.tsx`
- `src/components/layout/Sidebar.tsx`
- `src/components/layout/Layout.tsx`
- `src/App.tsx`

**Features**:
- [ ] Header with app title and local-first indicator
- [ ] Sidebar with navigation links
- [ ] Responsive layout (mobile hamburger menu)
- [ ] Route setup with React Router
- [ ] Page transitions

**Deliverables**:
- [ ] Layout components
- [ ] Navigation structure
- [ ] Route configuration

### Task 7: Common Components (1-2 days)

**Files to Create**:
- `src/components/common/Button.tsx`
- `src/components/common/Card.tsx`
- `src/components/common/Input.tsx`
- `src/components/common/Select.tsx`
- `src/components/common/Modal.tsx`
- `src/components/common/ProgressBar.tsx`

**Deliverables**:
- [ ] Reusable UI components
- [ ] Consistent styling with Tailwind
- [ ] Accessibility features
- [ ] Component documentation

### Task 8: Testing Setup (1-2 days)

**Files to Create**:
- `tests/unit/storage.test.ts`
- `tests/unit/hooks.test.ts`
- `tests/fixtures/testData.ts`
- `vitest.config.ts`
- `playwright.config.ts`

**Deliverables**:
- [ ] Unit test setup and examples
- [ ] E2E test setup and examples
- [ ] Test data fixtures
- [ ] CI/CD configuration

## Implementation Checklist

### Week 1
- [ ] Project initialization
- [ ] IndexedDB integration
- [ ] Custom hooks
- [ ] Basic form components

### Week 2
- [ ] Complete form components
- [ ] Multi-step form container
- [ ] Layout and navigation
- [ ] Common components

### Week 3
- [ ] Testing setup
- [ ] Integration testing
- [ ] Bug fixes and refinements
- [ ] Documentation updates

## Success Criteria

- [ ] All form data persists to IndexedDB
- [ ] Forms validate input correctly
- [ ] Multi-step form navigation works smoothly
- [ ] Data survives browser refresh
- [ ] No console errors or warnings
- [ ] Mobile responsive design works
- [ ] Unit tests pass (>80% coverage)
- [ ] E2E tests for basic workflows pass

## Dependencies to Install

```json
{
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "react-router-dom": "^6.x.x",
    "zustand": "^4.x.x"
  },
  "devDependencies": {
    "typescript": "^5.x.x",
    "@types/react": "^18.x.x",
    "@types/react-dom": "^18.x.x",
    "vite": "^5.x.x",
    "@vitejs/plugin-react": "^4.x.x",
    "tailwindcss": "^3.x.x",
    "postcss": "^8.x.x",
    "autoprefixer": "^10.x.x",
    "vitest": "^1.x.x",
    "@testing-library/react": "^14.x.x",
    "@testing-library/jest-dom": "^6.x.x",
    "@playwright/test": "^1.x.x"
  }
}
```

## Notes

- Follow TypeScript strict mode
- Use functional components with hooks
- Implement proper error boundaries
- Add loading states for all async operations
- Test on mobile devices during development
- Keep components small and focused
- Document complex logic with comments

## Rollover to Phase 3

Once Phase 2 is complete:
1. All user data persists correctly to IndexedDB
2. Forms are fully functional and validated
3. Multi-step form navigation works smoothly
4. Basic layout and navigation are in place
5. Unit tests are passing

Then proceed to Phase 3: Viability Algorithm & Flowcharts

