# 🇵🇹 🇬🇷 🇨🇾 🇲🇹 PHASE 10 TEAM PLAN - MEDITERRANEAN COUNTRIES

**Date**: 2025-10-20  
**Status**: 🚀 **STARTING**  
**Countries**: Portugal, Greece, Cyprus, Malta  
**Target**: 4 countries, 20 visa programs, 8 flowcharts

---

## 🎯 Phase 10 Overview

Phase 10 focuses on **Mediterranean/Southern European countries** - Portugal, Greece, Cyprus, and Malta. These countries are known for:
- ✅ Lower cost of living than Western/Nordic Europe
- ✅ Golden Visa programs (investment-based immigration)
- ✅ Popular with digital nomads and retirees
- ✅ English widely spoken (Cyprus, Malta)
- ✅ Warm climate and Mediterranean lifestyle
- ✅ Growing tech sectors

---

## 👥 Team Assignments

### 🏗️ Architecture Engineer
**Responsibilities**:
- Research visa programs for all 4 countries from official sources
- Define program requirements, salary thresholds, processing times
- Ensure data structure consistency with existing countries
- Identify special programs (Golden Visa, D7, Digital Nomad, etc.)

**Deliverables**:
- `PHASE_10_RESEARCH.md` with comprehensive research for all 4 countries
- Program specifications for 20 visa programs (5 per country)
- Official source URLs and documentation

---

### 💻 Frontend Engineer
**Responsibilities**:
- Implement visa programs in `src/data/visaPrograms.ts`
- Create flowchart files for all 4 countries
- Update `src/pages/Flowchart.tsx` with new countries
- Ensure UI properly displays new countries

**Deliverables**:
- 4 program arrays (PORTUGAL_PROGRAMS, GREECE_PROGRAMS, CYPRUS_PROGRAMS, MALTA_PROGRAMS)
- 4 flowchart files (portugal.ts, greece.ts, cyprus.ts, malta.ts)
- Updated Flowchart page with all 4 countries

---

### 📋 Product Manager
**Responsibilities**:
- Prioritize programs for each country (most popular/useful first)
- Define user stories for Mediterranean country users
- Review program descriptions for clarity
- Ensure programs meet user needs (digital nomads, retirees, investors)

**Deliverables**:
- Program priority rankings for each country
- User stories for Phase 10
- Program description reviews

---

### 🧪 QA Automation Engineer
**Responsibilities**:
- Run full test suite after each country implementation
- Verify no regressions on existing 12 countries
- Test new programs with various user profiles
- Validate flowchart rendering for all new countries

**Deliverables**:
- Test reports for each country
- Regression test results
- Bug reports (if any)

---

### 🎨 UX Designer
**Responsibilities**:
- Design flowcharts for 8 programs (2 per country)
- Ensure flowchart consistency with existing patterns
- Review user experience for Mediterranean country selection
- Validate Mermaid diagram syntax

**Deliverables**:
- 8 flowchart designs (2 per country)
- UX review document

---

### 📊 Coordinator
**Responsibilities**:
- Manage overall Phase 10 timeline
- Coordinate between team members
- Track progress and update documentation
- **Ensure each country is 100% complete before moving to next**
- Create completion documents for each country
- **Update existing documentation (EU_EXPANSION_PLAN.md, etc.)**

**Deliverables**:
- This plan document
- Progress tracking updates (`PHASE_10_STATUS.md`)
- `PHASE_10_PORTUGAL_COMPLETE.md`
- `PHASE_10_GREECE_COMPLETE.md`
- `PHASE_10_CYPRUS_COMPLETE.md`
- `PHASE_10_MALTA_COMPLETE.md`
- `PHASE_10_COMPLETE.md`
- Updated `EU_EXPANSION_PLAN.md`

---

## 📅 Timeline

### Week 1: Portugal 🇵🇹
- **Day 1-2**: Research Portuguese visa programs (Golden Visa, D7, Tech Visa, etc.)
- **Day 3-4**: Implement programs and flowcharts
- **Day 5**: Test, document, and complete Portugal

### Week 2: Greece 🇬🇷
- **Day 1-2**: Research Greek visa programs (Golden Visa, Digital Nomad, etc.)
- **Day 3-4**: Implement programs and flowcharts
- **Day 5**: Test, document, and complete Greece

### Week 3: Cyprus 🇨🇾
- **Day 1-2**: Research Cyprus visa programs (Golden Visa, Startup, etc.)
- **Day 3-4**: Implement programs and flowcharts
- **Day 5**: Test, document, and complete Cyprus

### Week 4: Malta 🇲🇹
- **Day 1-2**: Research Malta visa programs (Golden Visa, Nomad Residence, etc.)
- **Day 3-4**: Implement programs and flowcharts
- **Day 5**: Test, document, and complete Malta

---

## ✅ Success Criteria

### Per Country
- [ ] 5 visa programs implemented
- [ ] 2 flowcharts created (most popular programs)
- [ ] All tests passing (no regressions)
- [ ] Build and lint passing
- [ ] Country completion document created
- [ ] Country added to Flowchart dropdown

### Overall Phase 10
- [ ] 4 countries added (Portugal, Greece, Cyprus, Malta)
- [ ] 20 visa programs total
- [ ] 8 flowcharts total
- [ ] Application supports 16 countries
- [ ] 82 total visa programs
- [ ] 27 total flowcharts
- [ ] All 237+ tests passing

---

## 🌟 Mediterranean Countries Overview

### 🇵🇹 Portugal
**Priority**: HIGHEST  
**Why**: Very popular with digital nomads, D7 Visa, Golden Visa, growing tech scene

**Expected Programs**:
1. Golden Visa (€500k investment)
2. D7 Visa (Passive Income - most popular!)
3. Tech Visa (for tech workers)
4. Startup Visa
5. Family Reunification

**Key Features**:
- Lower cost of living than Western Europe
- English widely spoken in cities
- D7 Visa very popular with retirees/digital nomads
- Strong expat community
- PR in 5 years, citizenship in 5 years
- Non-habitual resident tax regime (10 years)

---

### 🇬🇷 Greece
**Priority**: HIGH  
**Why**: Golden Visa, low cost of living, growing digital nomad scene

**Expected Programs**:
1. Golden Visa (€250k investment - lowest in EU!)
2. Digital Nomad Visa
3. Independent Means Visa
4. Work Permit
5. Family Reunification

**Key Features**:
- Lowest Golden Visa threshold in EU (€250k)
- Very low cost of living
- Beautiful islands and climate
- Growing digital nomad community
- PR in 5 years, citizenship in 7 years

---

### 🇨🇾 Cyprus
**Priority**: HIGH  
**Why**: English-speaking, tax benefits, EU member

**Expected Programs**:
1. Golden Visa (€300k investment)
2. Startup Visa
3. Work Permit
4. Digital Nomad Visa
5. Family Reunification

**Key Features**:
- English is official language
- Low corporate tax (12.5%)
- Warm climate year-round
- Strategic location (Europe/Asia/Africa)
- PR in 5 years, citizenship in 7 years

---

### 🇲🇹 Malta
**Priority**: MEDIUM  
**Why**: English-speaking, tax benefits, small but attractive

**Expected Programs**:
1. Golden Visa (€300k investment)
2. Nomad Residence Permit
3. Highly Skilled Worker Permit
4. Startup Visa
5. Family Reunification

**Key Features**:
- English is official language
- EU member with strong economy
- Tax benefits for expats
- Small island nation (easy to navigate)
- PR in 5 years, citizenship in 5 years

---

## 🎯 Key Themes for Phase 10

### Golden Visa Programs
All 4 countries have Golden Visa (investment-based) programs:
- **Greece**: €250k (lowest!)
- **Cyprus**: €300k
- **Malta**: €300k
- **Portugal**: €500k

### Digital Nomad/Remote Work
- Portugal: D7 Visa (passive income)
- Greece: Digital Nomad Visa
- Cyprus: Digital Nomad Visa
- Malta: Nomad Residence Permit

### Lower Cost of Living
- Greece: Very low
- Portugal: Low-Medium
- Cyprus: Medium
- Malta: Medium

### English-Friendly
- Cyprus: English is official language
- Malta: English is official language
- Portugal: English widely spoken in cities
- Greece: English common in tourist areas

---

## 📊 Expected Application Growth

**Before Phase 10**:
- Countries: 12
- Visa Programs: 62
- Flowcharts: 19
- EU Coverage: 44% (12/27)

**After Phase 10**:
- Countries: **16** (+4, +33%)
- Visa Programs: **82** (+20, +32%)
- Flowcharts: **27** (+8, +42%)
- EU Coverage: **59%** (16/27)

---

## 🚀 Let's Begin!

**First Country**: Portugal 🇵🇹  
**Starting Now**: Research phase

The team will work together to complete Portugal first, then move to Greece, Cyprus, and Malta in sequence. Each country will be 100% complete (programs + flowcharts + tests + docs) before moving to the next!

---

**Coordinator Note**: This plan follows the successful pattern from Phase 8 and Phase 9. We will maintain detailed documentation throughout and ensure no regressions. Let's make Phase 10 excellent! 🌊

