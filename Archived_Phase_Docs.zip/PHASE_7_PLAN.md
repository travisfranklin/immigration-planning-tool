# Phase 7: Immigration Process Flowcharts & Data Management

**Status**: 📋 Planning  
**Date**: 2025-10-19  
**Prerequisites**: Phase 6 Complete ✅

---

## 🎯 Overview

Phase 7 focuses on two key areas:
1. **Immigration Process Flowcharts** - Visual guides showing the step-by-step immigration process for each visa program
2. **Data Management & Settings** - User data export, import, deletion, and application preferences

---

## 📊 Phase 7 Scope

### 1. Immigration Process Flowcharts

#### Flowchart Features
- **Visual Process Maps**: Step-by-step flowcharts for each of the 27 visa programs
- **Interactive Elements**: Clickable nodes with detailed information
- **Timeline Indicators**: Estimated duration for each step
- **Document Checklists**: Required documents at each stage
- **Decision Points**: Conditional paths based on user circumstances
- **Progress Tracking**: Mark completed steps

#### Flowchart Components
- **Mermaid.js Integration**: Render flowcharts using Mermaid syntax
- **Flowchart Data**: JSON definitions for each visa program's process
- **Flowchart Viewer**: Interactive component to display and navigate flowcharts
- **Flowchart Page**: Dedicated page for viewing immigration processes
- **Flowchart Export**: Export flowcharts as PNG/SVG

#### Example Flowchart Structure
```
Start → Gather Documents → Submit Application → Wait for Processing → 
Interview (if required) → Decision → Approval/Rejection → 
Next Steps (Visa Issuance / Appeal)
```

### 2. Data Management & Settings

#### Data Export
- **Export Formats**: JSON, PDF (summary report)
- **Export Options**:
  - Full profile data
  - Viability scores only
  - Complete report (profile + scores + flowcharts)
- **Timestamped Files**: Automatic filename with date/time
- **Privacy Notice**: Reminder about data sensitivity

#### Data Import
- **Import from JSON**: Restore previously exported profile
- **Validation**: Verify imported data structure
- **Merge Options**: Overwrite or merge with existing data
- **Error Handling**: Clear messages for invalid imports

#### Data Deletion
- **Clear All Data**: Delete all user data from IndexedDB
- **Selective Deletion**: Delete specific profiles or scores
- **Confirmation Dialog**: Prevent accidental deletion
- **No Recovery**: Clear warning that deletion is permanent

#### Settings & Preferences
- **Display Preferences**:
  - Theme (light/dark mode)
  - Language (English initially, extensible)
  - Units (metric/imperial)
- **Calculation Preferences**:
  - Include/exclude specific countries
  - Adjust component weights (advanced users)
- **Privacy Settings**:
  - Optional data encryption
  - Auto-clear on browser close
- **About Section**:
  - App version
  - Privacy policy
  - Data storage information

---

## 📁 Files to Create

### Flowchart System (8 files)
1. `src/data/flowcharts/` - Directory for flowchart definitions
2. `src/data/flowcharts/germany.ts` - Germany visa flowcharts
3. `src/data/flowcharts/netherlands.ts` - Netherlands visa flowcharts
4. `src/data/flowcharts/france.ts` - France visa flowcharts
5. `src/data/flowcharts/spain.ts` - Spain visa flowcharts
6. `src/data/flowcharts/italy.ts` - Italy visa flowcharts
7. `src/components/flowchart/FlowchartViewer.tsx` - Flowchart display component
8. `src/pages/Flowchart.tsx` - Flowchart page

### Data Management (6 files)
9. `src/services/export/exportService.ts` - Export functionality
10. `src/services/import/importService.ts` - Import functionality
11. `src/services/storage/settingsStore.ts` - Settings persistence
12. `src/types/settings.ts` - Settings type definitions
13. `src/pages/Settings.tsx` - Settings page
14. `src/components/settings/DataManagement.tsx` - Data management UI

### Supporting Components (4 files)
15. `src/components/settings/ExportDialog.tsx` - Export options dialog
16. `src/components/settings/ImportDialog.tsx` - Import dialog
17. `src/components/settings/DeleteConfirmation.tsx` - Delete confirmation
18. `src/components/settings/PreferencesPanel.tsx` - Preferences UI

---

## 🎨 UI Design

### Flowchart Page
```
┌─────────────────────────────────────────────────────────┐
│  Immigration Process Flowchart                          │
├─────────────────────────────────────────────────────────┤
│  Country: [Germany ▼]  Program: [EU Blue Card ▼]       │
├─────────────────────────────────────────────────────────┤
│                                                          │
│  ┌──────────────────────────────────────────────────┐  │
│  │                                                   │  │
│  │         [Mermaid Flowchart Rendered Here]        │  │
│  │                                                   │  │
│  │  Start → Gather Docs → Submit → Wait → ...      │  │
│  │                                                   │  │
│  └──────────────────────────────────────────────────┘  │
│                                                          │
│  [Export as PNG] [Export as SVG] [Print]               │
│                                                          │
│  Step Details:                                          │
│  ┌──────────────────────────────────────────────────┐  │
│  │ Step 1: Gather Required Documents                │  │
│  │ • Passport (valid for 6+ months)                 │  │
│  │ • Job offer letter                               │  │
│  │ • University degree certificate                  │  │
│  │ • Proof of health insurance                      │  │
│  │ Estimated time: 2-4 weeks                        │  │
│  └──────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────┘
```

### Settings Page
```
┌─────────────────────────────────────────────────────────┐
│  Settings                                                │
├─────────────────────────────────────────────────────────┤
│                                                          │
│  Data Management                                        │
│  ┌──────────────────────────────────────────────────┐  │
│  │ Export Data                                       │  │
│  │ [Export Profile] [Export Scores] [Export All]    │  │
│  │                                                   │  │
│  │ Import Data                                       │  │
│  │ [Choose File...] [Import]                        │  │
│  │                                                   │  │
│  │ Delete Data                                       │  │
│  │ [Delete All Data] ⚠️ Cannot be undone            │  │
│  └──────────────────────────────────────────────────┘  │
│                                                          │
│  Preferences                                            │
│  ┌──────────────────────────────────────────────────┐  │
│  │ Theme: [Light ▼]                                 │  │
│  │ Language: [English ▼]                            │  │
│  │ Units: [Metric ▼]                                │  │
│  └──────────────────────────────────────────────────┘  │
│                                                          │
│  About                                                  │
│  ┌──────────────────────────────────────────────────┐  │
│  │ Version: 1.0.0                                    │  │
│  │ All data stored locally on your device           │  │
│  │ No server. No cloud. Complete privacy.           │  │
│  └──────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────┘
```

---

## 🔄 Implementation Order

### Week 1: Flowchart Foundation
1. Create flowchart data structure and types
2. Implement Mermaid.js integration
3. Create FlowchartViewer component
4. Build flowchart definitions for Germany (5 programs)
5. Create Flowchart page with country/program selector

### Week 2: Complete Flowcharts
6. Build flowchart definitions for Netherlands (5 programs)
7. Build flowchart definitions for France (5 programs)
8. Build flowchart definitions for Spain (5 programs)
9. Build flowchart definitions for Italy (5 programs)
10. Add flowchart export functionality (PNG/SVG)

### Week 3: Data Management
11. Implement export service (JSON, PDF)
12. Implement import service with validation
13. Create Settings page structure
14. Build DataManagement component
15. Add delete functionality with confirmation

### Week 4: Settings & Polish
16. Implement preferences (theme, language, units)
17. Create settings persistence layer
18. Add About section
19. Write tests for all new functionality
20. Integration testing and bug fixes

---

## ✅ Success Criteria

- [ ] All 27 visa programs have flowchart definitions
- [ ] Flowcharts render correctly using Mermaid.js
- [ ] Users can export flowcharts as PNG/SVG
- [ ] Users can export their data as JSON
- [ ] Users can import previously exported data
- [ ] Users can delete all data with confirmation
- [ ] Settings persist across sessions
- [ ] All new features have unit tests
- [ ] E2E tests cover flowchart and settings flows
- [ ] Build passes with no errors
- [ ] Linting passes with no errors

---

## 🚀 Next Steps

1. Review and approve Phase 7 plan
2. Begin implementation with flowchart foundation
3. Iterate on flowchart definitions with user feedback
4. Complete data management features
5. Test thoroughly
6. Move to Phase 8 (if needed) or finalize MVP

---

**Phase 7 will complete the core MVP functionality and provide users with comprehensive immigration guidance!**

