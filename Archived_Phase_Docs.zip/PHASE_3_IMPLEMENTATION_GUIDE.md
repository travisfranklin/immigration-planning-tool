# Phase 3: Form Components & Multi-Step Form Implementation Guide

**Phase**: Phase 3 (Continuation of Phase 2)  
**Duration**: 2-3 days  
**Status**: 🔄 READY TO START  
**Estimated Completion**: 2025-10-21

---

## 🎯 Phase 3 Objectives

1. ✅ Create 7 form components for user profile data collection
2. ✅ Build multi-step form container with navigation
3. ✅ Implement form validation and error handling
4. ✅ Add auto-save functionality with debounce
5. ✅ Create profile creation page
6. ✅ Implement form state management
7. ✅ Ensure responsive design and accessibility

---

## 📋 Task Breakdown

### Task 1: Form Components (1 day)

Create individual form components for each profile section:

#### 1.1 PersonalInfoForm
- **Fields**: firstName, lastName, dateOfBirth, citizenship
- **Validation**: Required fields, valid date format
- **File**: `src/components/forms/PersonalInfoForm.tsx`

#### 1.2 FinancialInfoForm
- **Fields**: annualIncome, savingsAmount, employmentStatus, hasHealthInsurance
- **Validation**: Positive numbers, valid employment status
- **File**: `src/components/forms/FinancialInfoForm.tsx`

#### 1.3 EducationForm
- **Fields**: educationLevel, fieldOfStudy, yearsOfExperience
- **Validation**: Valid education level, positive years
- **File**: `src/components/forms/EducationForm.tsx`

#### 1.4 CareerForm
- **Fields**: currentOccupation, occupationCode, industryType
- **Validation**: Required fields, valid occupation
- **File**: `src/components/forms/CareerForm.tsx`

#### 1.5 FamilyForm
- **Fields**: maritalStatus, familyMembers (array)
- **Validation**: Valid marital status, family member details
- **File**: `src/components/forms/FamilyForm.tsx`

#### 1.6 LanguageForm
- **Fields**: languages (array with proficiency levels)
- **Validation**: Valid language codes, valid proficiency levels
- **File**: `src/components/forms/LanguageForm.tsx`

#### 1.7 CountrySelectionForm
- **Fields**: targetCountries, immigrationPath, timelineMonths, hasJobOffer, jobOfferCountry
- **Validation**: At least one country selected, valid path
- **File**: `src/components/forms/CountrySelectionForm.tsx`

### Task 2: Multi-Step Form Container (1 day)

Create orchestration component:

#### 2.1 ProfileFormContainer
- **File**: `src/components/forms/ProfileFormContainer.tsx`
- **Features**:
  - Step navigation (Previous, Next, Submit)
  - Progress indicator showing current step
  - Form state management across steps
  - Validation before advancing
  - Auto-save to IndexedDB
  - Error handling and display

#### 2.2 ProgressIndicator Component
- **File**: `src/components/ProgressIndicator.tsx`
- **Features**:
  - Visual step indicator
  - Current step highlighting
  - Completed step marking

### Task 3: Profile Creation Page (0.5 day)

#### 3.1 ProfilePage
- **File**: `src/pages/Profile.tsx`
- **Features**:
  - Wrapper for ProfileFormContainer
  - Page layout and styling
  - Navigation back to home

### Task 4: Form Utilities (0.5 day)

#### 4.1 Validation Functions
- **File**: `src/utils/validation.ts`
- **Functions**:
  - validateEmail()
  - validatePhoneNumber()
  - validateDate()
  - validatePositiveNumber()
  - validateLanguageProficiency()
  - validateOccupationCode()

#### 4.2 Form State Management
- **File**: `src/utils/formState.ts`
- **Functions**:
  - mergeFormData()
  - validateFormStep()
  - calculateFormProgress()

---

## 🏗️ Architecture

### Form Component Structure
```
src/components/forms/
├── PersonalInfoForm.tsx
├── FinancialInfoForm.tsx
├── EducationForm.tsx
├── CareerForm.tsx
├── FamilyForm.tsx
├── LanguageForm.tsx
├── CountrySelectionForm.tsx
├── ProfileFormContainer.tsx
└── index.ts
```

### Form Flow
```
Home Page
    ↓
Profile Page
    ↓
ProfileFormContainer (Multi-Step)
    ├── Step 1: PersonalInfoForm
    ├── Step 2: FinancialInfoForm
    ├── Step 3: EducationForm
    ├── Step 4: CareerForm
    ├── Step 5: FamilyForm
    ├── Step 6: LanguageForm
    └── Step 7: CountrySelectionForm
    ↓
Dashboard (Phase 4)
```

---

## 🔄 Form State Management

### State Structure
```typescript
interface FormState {
  currentStep: number;
  totalSteps: number;
  formData: Partial<UserProfile>;
  errors: Record<string, string>;
  touched: Record<string, boolean>;
  isSubmitting: boolean;
  isDirty: boolean;
}
```

### Auto-Save Strategy
- Debounce: 1 second after user stops typing
- Save to IndexedDB on each step completion
- Show save indicator (optional)
- Handle save errors gracefully

---

## ✅ Success Criteria

- [ ] All 7 form components created and functional
- [ ] Multi-step form navigation works smoothly
- [ ] Form validation prevents invalid data submission
- [ ] Auto-save persists data to IndexedDB
- [ ] Data survives page refresh
- [ ] Responsive design works on mobile
- [ ] Accessibility features implemented (ARIA labels, keyboard navigation)
- [ ] No console errors or warnings
- [ ] Form state properly managed across steps
- [ ] Error messages display clearly

---

## 📝 Implementation Notes

### Form Component Template
```typescript
import { useState } from 'react';
import type { UserProfile } from '../../types/user';
import { Input, Select, Button } from '../index';

interface FormProps {
  data: Partial<UserProfile>;
  errors: Record<string, string>;
  onChange: (field: string, value: any) => void;
  onBlur: (field: string) => void;
}

export function PersonalInfoForm({ data, errors, onChange, onBlur }: FormProps) {
  return (
    <div className="space-y-4">
      {/* Form fields */}
    </div>
  );
}
```

### Validation Pattern
```typescript
function validateStep(step: number, data: Partial<UserProfile>): Record<string, string> {
  const errors: Record<string, string> = {};
  
  if (step === 1) {
    if (!data.firstName) errors.firstName = 'First name is required';
    if (!data.lastName) errors.lastName = 'Last name is required';
    // ... more validations
  }
  
  return errors;
}
```

---

## 🚀 Next Steps After Phase 3

1. **Phase 4**: Viability Algorithm Implementation
   - Implement scoring algorithm
   - Calculate component scores
   - Generate risk factors
   - Create contingencies

2. **Phase 5**: Dashboard & Results
   - Country ranking display
   - Viability score cards
   - Risk factor visualization
   - Contingency planning UI

3. **Phase 6**: Testing
   - Unit tests for forms
   - E2E tests for user flows
   - Data persistence tests

---

## 📊 Estimated Timeline

| Task | Duration | Status |
|------|----------|--------|
| Form Components | 1 day | ⏳ Pending |
| Multi-Step Container | 1 day | ⏳ Pending |
| Profile Page | 0.5 day | ⏳ Pending |
| Validation Utils | 0.5 day | ⏳ Pending |
| **Total** | **3 days** | ⏳ Pending |

---

## 🎓 Key Concepts

- **Controlled Components**: Form inputs controlled by React state
- **Form Validation**: Client-side validation before submission
- **Auto-Save**: Debounced saves to IndexedDB
- **Multi-Step Forms**: Step-by-step data collection
- **Error Handling**: Clear error messages for users
- **Accessibility**: WCAG 2.1 AA compliance

---

**Status**: 🟢 READY TO IMPLEMENT  
**Next Review**: After Task 1 completion  
**Estimated Phase 3 Completion**: 2025-10-21

